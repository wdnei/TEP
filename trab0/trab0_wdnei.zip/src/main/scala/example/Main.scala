package example

import common._


object Main extends App {
  println(Lists.max(List(1,3,2)));
  println("Aluno:Wdnei Ribeiro da Paixao");

}
